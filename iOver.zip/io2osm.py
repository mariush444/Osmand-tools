#!/usr/bin/python3

import datetime

input_file = "io-export.gpx"

# mariush444 v-fast-2.0 240702
# other tools - https://mariush444.github.io/Osmand-tools/

# questions, requests, ideas
# github https://github.com/osmandapp/OsmAnd/issues/19971
# reddit https://www.reddit.com/r/OsmAnd/new/
# telegram https://t.me/OsmAndMaps

# HOW TO RUN
# copy gpx from iOverlander and the script into the same directory
# useing text editor change input file name (line no 5)
# OR chenge exported gpx to io-export.gpx
# in Pydroid 3 (install from Google play store)
# in menu choose option Terminal
# change directory where you copied script and gpx (use command: cd PATH)
# run scrpit (use command: ./io2osm.py)
# when finnished, you find new gpx file in the directory

# HOW TO MODIFY
# open script in text editor
# you can modify icons, shape and colors as you need
# it is just my proposition


# list of posible icons -> https://github.com/mariush444/gmapIcons2osmand/blob/main/icons-gmap-osmand.pdf
# posible backgrounds/shapes -> circle, square, octagon
# color -> any color that you need
# variable a -> name in gpx (see info below), icon, background/shape, color 
# name in gpx can be change as it is needed
# e.g. "1. Wild camp" will be at the begining of the list
# e.g. Wild camp and Informal camp can have the same name and they all will be in one group
# e.g. "Consulate / Embassy" can be shorten to "diplomatic" and so on ...

a20='<type>Checkpoint</type><extensions><osmand:icon>amenity_police</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#D8031A</osmand:color></extensions>'
a17='<type>Consulate / Embassy</type><extensions><osmand:icon>special_poi_us_capitol</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#D8031A</osmand:color></extensions>'
a12='<type>Customs and Immigration</type><extensions><osmand:icon>barrier_border_control</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#D8031A</osmand:color></extensions>'
a29='<type>Eco-Friendly</type><extensions><osmand:icon>agrarian</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#FA8D69</osmand:color></extensions>'
a2='<type>Established Campground</type><extensions><osmand:icon>tourism_camp_site</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#1F643F</osmand:color></extensions>'
a30='<type>Financial</type><extensions><osmand:icon>amenity_atm</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#4695EF</osmand:color></extensions>'
a14='<type>Fuel Station</type><extensions><osmand:icon>fuel</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#FA8D69</osmand:color></extensions>'
a7='<type>Hostel</type><extensions><osmand:icon>tourism_hostel</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#1010a0</osmand:color></extensions>'
a6='<type>Hotel</type><extensions><osmand:icon>tourism_hotel</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#1010a0</osmand:color></extensions>'
a3='<type>Informal Campsite</type><extensions><osmand:icon>building</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#1F643F</osmand:color></extensions>'
a25='<type>Laundromat</type><extensions><osmand:icon>shop_laundry</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#4695EF</osmand:color></extensions>'
a26='<type>Laundry</type><extensions><osmand:icon>shop_laundry</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#4695EF</osmand:color></extensions>'
a9='<type>Mechanic and Parts</type><extensions><osmand:icon>service</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#FA8D69</osmand:color></extensions>'
a23='<type>Medical</type><extensions><osmand:icon>clinic</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#4695EF</osmand:color></extensions>'
a1='<type>Official Campground</type><extensions><osmand:icon>tourism_camp_site</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#1F643F</osmand:color></extensions>'
a13='<type>Other</type><extensions><osmand:icon>special_star</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#4695EF</osmand:color></extensions>'
a4='<type>Overnight Prohibited</type><extensions><osmand:icon>access_private</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#D8031A</osmand:color></extensions>'
a24='<type>Pet Services</type><extensions><osmand:icon>shop_pet</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#4695EF</osmand:color></extensions>'
a8='<type>Propane</type><extensions><osmand:icon>gas</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#FA8D69</osmand:color></extensions>'
a11='<type>Restaurant</type><extensions><osmand:icon>restaurants</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#4695EF</osmand:color></extensions>'
a16='<type>Sanitation Dump Station</type><extensions><osmand:icon>sanitary_dump_station</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#FA8D69</osmand:color></extensions>'
a22='<type>Shopping</type><extensions><osmand:icon>shop_supermarket</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#4695EF</osmand:color></extensions>'
a28='<type>Short-term Parking</type><extensions><osmand:icon>amenity_parking</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#FA8D69</osmand:color></extensions>'
a32='<type>Showers</type><extensions><osmand:icon>shower</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#4695EF</osmand:color></extensions>'
a15='<type>Tourist Attraction</type><extensions><osmand:icon>camera</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#4695EF</osmand:color></extensions>'
a18='<type>Vehicle Insurance</type><extensions><osmand:icon>insurance</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#FA8D69</osmand:color></extensions>'
a19='<type>Vehicle Shipping</type><extensions><osmand:icon>cargo_vehicle</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#FA8D69</osmand:color></extensions>'
a27='<type>Vehicle Storage</type><extensions><osmand:icon>parking_multi_storey</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#FA8D69</osmand:color></extensions>'
a21='<type>Warning</type><extensions><osmand:icon>hazard</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#D8031A</osmand:color></extensions>'
a10='<type>Water</type><extensions><osmand:icon>water_tap</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#FA8D69</osmand:color></extensions>'
a31='<type>Wifi</type><extensions><osmand:icon>internet_access_wlan</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#4695EF</osmand:color></extensions>'
a5='<type>Wild Camping</type><extensions><osmand:icon>forest</osmand:icon><osmand:background>circle</osmand:background><osmand:color>#1F643F</osmand:color></extensions>'

output_file = input_file.replace(".gpx","")+datetime.datetime.now().strftime("%y%m%d")+".gpx"
f1 = open(input_file, "r") 
f2 = open(output_file, "w")

# print(datetime.datetime.now().strftime("%h%m%s"))
for line in f1:
	if line.find('</sym>') < 0 and line != "\n":
		f2.write(line
		.replace('<type>Official Campground</type>' ,a1)
		.replace('<type>Established Campground</type>' ,a2)
		.replace('<type>Informal Campsite</type>' ,a3)
		.replace('<type>Overnight Prohibited</type>' ,a4)
		.replace('<type>Wild Camping</type>' ,a5 )
		.replace('<type>Hotel</type>' ,a6)
		.replace('<type>Hostel</type>' ,a7)
		.replace('<type>Propane</type>' ,a8)
		.replace('<type>Mechanic and Parts</type>' , a9)
		.replace('<type>Water</type>' ,a10)
		.replace('<type>Restaurant</type>' ,a11)
		.replace('<type>Customs and Immigration</type>' , a12)
		.replace('<type>Other</type>' ,a13)
		.replace('<type>Fuel Station</type>' ,a14)
		.replace('<type>Tourist Attraction</type>' ,a15)
		.replace('<type>Sanitation Dump Station</type>' ,a16)
		.replace('<type>Consulate / Embassy</type>' ,a17)
		.replace('<type>Vehicle Insurance</type>' ,a18)
		.replace('<type>Vehicle Shipping</type>' ,a19)
		.replace('<type>Checkpoint</type>' ,a20)
		.replace('<type>Warning</type>' ,a21)
		.replace('<type>Shopping</type>' ,a22)
		.replace('<type>Medical</type>' ,a23)
		.replace('<type>Pet Services</type>' ,a24)
		.replace('<type>Laundromat</type>' ,a25)
		.replace('<type>Laundry</type>' ,a26)
		.replace('<type>Vehicle Storage</type>' ,a27)
		.replace('<type>Short-term Parking</type>' ,a28)
		.replace('<type>Eco-Friendly</type>' ,a29)
		.replace('<type>Financial</type>' ,a30)
		.replace('<type>Wifi</type>' ,a31)
		.replace('<type>Showers</type>' ,a32)
		.replace('<gpx' ,'<gpx  xmlns:osmand="https://osmand.net" ')
		.replace('</gpx>' ,'  <extensions>\n'+
		'<osmand:points_groups>\n'+
	      a1.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a2.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a3.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a4.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a5.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a6.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a7.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a8.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a9.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a10.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a11.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a12.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a13.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a14.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a15.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a16.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a17.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a18.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a19.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a20.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a21.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a22.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a23.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a24.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a25.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a26.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a27.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a28.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a29.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a30.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a31.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      a32.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n')+
	      '</osmand:points_groups>\n'+
	  '</extensions> \n'+ 
	'</gpx>\n')
		)
# print(datetime.datetime.now().strftime("%h%m%s"))
# print(a1.replace('<type>','<group name="').replace('</type><extensions><osmand:icon>','" icon="').replace('</osmand:icon><osmand:background>','" background="').replace('</osmand:background><osmand:color>','" color="').replace('</osmand:color></extensions>','"/>\n'))
#print(a5[50:72] 	
'''
'+ re.search('<osmand:icon>(.*)</osmand:icon>',a1).group(1)+ '
'''